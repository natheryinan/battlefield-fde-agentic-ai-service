from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

from src.llm.inference_client import LLMClient
from src.agents.planner_agent import PlannerAgent
from src.agents.retrieval_agent import RetrievalAgent
from src.agents.execution_agent import ExecutionAgent
from src.ops.monitoring import log_mission_event
from src.ops.evaluation_suite import simple_quality_score

app = FastAPI(
    title="Battlefield Agentic FDE AI Ops",
    description="Forward-deployed agentic system demo for FDRE-style work.",
    version="0.1.0",
)

llm = LLMClient()
retrieval_agent = RetrievalAgent()
planner = PlannerAgent(llm)
executor = ExecutionAgent(llm, retrieval_agent)

class PlanRequest(BaseModel):
    mission: str

class PlanResponse(BaseModel):
    steps: List[str]

class RunMissionRequest(BaseModel):
    mission: str

class RunMissionResponse(BaseModel):
    steps: List[str]
    outputs: List[str]
    quality_score: float

@app.post("/plan", response_model=PlanResponse)
def plan_mission(req: PlanRequest) -> PlanResponse:
    log_mission_event("plan_requested", {"mission": req.mission})
    steps = planner.plan(req.mission)
    return PlanResponse(steps=steps)

@app.post("/run-mission", response_model=RunMissionResponse)
def run_mission(req: RunMissionRequest) -> RunMissionResponse:
    log_mission_event("run_mission_requested", {"mission": req.mission})
    steps = planner.plan(req.mission)
    outputs = executor.execute_steps(steps)
    score = simple_quality_score(outputs)
    return RunMissionResponse(steps=steps, outputs=outputs, quality_score=score)

@app.get("/health")
def health_check() -> dict:
    return {"status": "ok"}
